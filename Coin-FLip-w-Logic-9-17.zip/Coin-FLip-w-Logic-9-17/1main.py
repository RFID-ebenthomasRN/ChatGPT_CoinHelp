import tkinter as tk
from DQN import DQN
from BayesianPredictor import BayesianPredictor
from FrequencyPredictor import FrequencyPredictor
from LSTMPredictor import LSTMPredictor
from CoinFlipAppGUI import CoinFlipAppGUI
import sqlite3


class CoinFlipApp:
    def __init__(self, master):
        self.master = master
        self.coin_flips = []
        self.dqn = DQN(1, 2)
        self.bayesian = BayesianPredictor()
        self.frequency = FrequencyPredictor()
        self.lstm = LSTMPredictor()
        self.gui = CoinFlipAppGUI(master, self.submit)
        self.conn = sqlite3.connect('coinflip.db')
        self.c = self.conn.cursor()
        self.c.execute('''CREATE TABLE IF NOT EXISTS flips (flip TEXT)''')
        print('Table flips should be created now.')  # Debugging print
        self.conn.commit()

    def submit(self, flip):
        print(f'Button pressed: {flip}')  # Debugging print
        self.coin_flips.append(flip)
        self.c.execute("INSERT INTO flips VALUES (?)", (flip,))
        self.conn.commit()
        dqn_pred = self.dqn.predict(self.coin_flips)
        bayesian_pred = self.bayesian.predict(self.coin_flips)
        freq_pred = self.frequency.predict(self.coin_flips)  # Fixed this line
        lstm_pred = self.lstm.predict(self.coin_flips)
        # Update GUI with these predictions

    def update_prediction(self):
        # Query the database for historical data
        self.c.execute("SELECT * FROM flips")
        historical_data = self.c.fetchall()
        # Update logic here, including database queries and model predictions


if __name__ == '__main__':
    root = tk.Tk()
    app = CoinFlipApp(root)
    root.mainloop()