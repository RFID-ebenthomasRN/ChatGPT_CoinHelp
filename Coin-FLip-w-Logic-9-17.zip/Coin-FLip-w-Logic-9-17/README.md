# Coin FLip w Logic 9/17
 coin flip recorder with predective logic 
